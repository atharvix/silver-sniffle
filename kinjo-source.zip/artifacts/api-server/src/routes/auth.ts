import { Router, type IRouter } from "express";
import { randomInt, randomBytes } from "crypto";
import { eq, lt } from "drizzle-orm";
import { db, otpCodesTable, verificationTokensTable, verifiedEmailsTable } from "@workspace/db";
import { SendOtpBody, VerifyOtpBody, SendWelcomeBody } from "@workspace/api-zod";

const router: IRouter = Router();

interface RateBucket {
  count: number;
  windowStart: number;
}

// In-memory stores. Rate-limit buckets are fine to lose on restart — worst
// case a user gets a couple of extra requests through, not locked out.
// OTP codes and verification tokens are persisted to the database (see
// otpCodesTable / verificationTokensTable) so a deploy doesn't wipe every
// in-flight sign-up or force every signed-in user to re-verify at once.
const sendRateByEmail = new Map<string, RateBucket>();
const sendRateByIp    = new Map<string, RateBucket>();

const EMAIL_RE            = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const OTP_TTL_MS          = 10 * 60 * 1000;
const MAX_VERIFY_ATTEMPTS = 5;
const EMAIL_WINDOW_MS     = 10 * 60 * 1000;
const EMAIL_MAX_SENDS     = 3;
const IP_WINDOW_MS        = 60 * 1000;
const IP_MAX_SENDS        = 10;

function generateOtp(): string {
  return String(randomInt(1000, 10000));
}

function isRateLimited(
  store: Map<string, RateBucket>,
  key: string,
  windowMs: number,
  maxCount: number,
): boolean {
  const now    = Date.now();
  const bucket = store.get(key);
  if (!bucket || now - bucket.windowStart > windowMs) {
    store.set(key, { count: 1, windowStart: now });
    return false;
  }
  if (bucket.count >= maxCount) return true;
  bucket.count += 1;
  return false;
}

// ── HTML escaping ─────────────────────────────────────────────────────────────

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// ── Verification token store ───────────────────────────────────────────────────
// After a successful OTP verification, we issue a random opaque token that the
// client must present (as "Authorization: Bearer <token>") on profile endpoints.
// The token is bound server-side to the verified email address.
//
// Persisted in Postgres (verificationTokensTable) rather than an in-memory Map:
// a Map is wiped on every server restart/deploy, which would instantly log out
// every signed-in user at once and force them all through re-verification
// simultaneously.

const VERIFIED_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

/**
 * Look up and validate a verification token.
 * Returns the bound email address if the token is valid, or null if not.
 * Exported for use by profile routes.
 */
export async function getEmailFromToken(token: string): Promise<string | null> {
  const [entry] = await db
    .select()
    .from(verificationTokensTable)
    .where(eq(verificationTokensTable.token, token));

  if (!entry) return null;

  if (Date.now() > entry.expiresAt.getTime()) {
    await db.delete(verificationTokensTable).where(eq(verificationTokensTable.token, token));
    return null;
  }

  return entry.email;
}

/**
 * Returns whether the given email has an unexpired verification record
 * (i.e. completed OTP verification recently). Used by /auth/send-welcome to
 * require proof of verification before sending a welcome email.
 */
async function isEmailVerified(email: string): Promise<boolean> {
  const [entry] = await db
    .select()
    .from(verificationTokensTable)
    .where(eq(verificationTokensTable.email, email));

  return !!entry && Date.now() <= entry.expiresAt.getTime();
}

/** Best-effort cleanup of expired rows; failures are non-fatal. */
async function cleanupExpired(): Promise<void> {
  const now = new Date();
  await Promise.all([
    db.delete(otpCodesTable).where(lt(otpCodesTable.expiresAt, now)).catch(() => {}),
    db.delete(verificationTokensTable).where(lt(verificationTokensTable.expiresAt, now)).catch(() => {}),
    db.delete(verifiedEmailsTable).where(lt(verifiedEmailsTable.expiresAt, now)).catch(() => {}),
  ]);
}

// ── Welcome rate limiting ──────────────────────────────────────────────────────
const welcomeRateByEmail = new Map<string, RateBucket>();
const welcomeRateByIp    = new Map<string, RateBucket>();
const WELCOME_EMAIL_WINDOW_MS = 60 * 60 * 1000; // 1 hour
const WELCOME_EMAIL_MAX       = 2;               // max 2 welcome emails per hour per address
const WELCOME_IP_WINDOW_MS    = 60 * 1000;       // 1 minute
const WELCOME_IP_MAX          = 20;              // max 20 per IP per minute

// ── Brevo email delivery ──────────────────────────────────────────────────────

const BREVO_TIMEOUT_MS = 10_000; // 10 s

function isBrevoConfigured(): boolean {
  return !!(process.env.BREVO_API_KEY && process.env.BREVO_SENDER_EMAIL);
}

async function sendOtpEmail(to: string, otp: string): Promise<void> {
  const apiKey      = process.env.BREVO_API_KEY!;
  const senderEmail = process.env.BREVO_SENDER_EMAIL!;

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>
<body style="margin:0;padding:0;background:#0e0b08;font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0e0b08;padding:40px 16px;">
    <tr><td align="center">
      <table width="100%" style="max-width:480px;">

        <!-- Logo -->
        <tr><td style="padding-bottom:32px;text-align:center;">
          <span style="font-size:26px;font-weight:900;color:#ffffff;letter-spacing:-1px;">Kinjo</span>
        </td></tr>

        <!-- Card -->
        <tr><td style="background:#141210;border:1px solid rgba(255,255,255,0.1);border-radius:14px;padding:40px 36px;">
          <p style="margin:0 0 8px;font-size:22px;font-weight:800;color:#ffffff;letter-spacing:-0.4px;">
            Your verification code
          </p>
          <p style="margin:0 0 28px;font-size:14px;color:rgba(255,255,255,0.5);line-height:1.55;">
            Enter this code to verify your email. It expires in 10&nbsp;minutes.
          </p>

          <!-- OTP box — white pill matching site CTA -->
          <div style="background:#ffffff;border-radius:14px;padding:24px;text-align:center;margin-bottom:28px;">
            <span style="font-size:42px;font-weight:900;color:#111111;letter-spacing:14px;">${otp}</span>
          </div>

          <p style="margin:0;font-size:13px;color:rgba(255,255,255,0.3);line-height:1.5;">
            If you didn&rsquo;t request this, you can safely ignore this email.
          </p>
        </td></tr>

        <!-- Footer -->
        <tr><td style="padding-top:24px;text-align:center;border-top:1px solid rgba(255,255,255,0.08);margin-top:24px;">
          <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.25);">Kinjo &middot; Discover people around you</p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`.trim();

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), BREVO_TIMEOUT_MS);

  try {
    const res = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: { "Content-Type": "application/json", "api-key": apiKey },
      body: JSON.stringify({
        sender:      { email: senderEmail, name: "Kinjo" },
        to:          [{ email: to }],
        subject:     `${otp} is your Kinjo verification code`,
        htmlContent: html,
      }),
      signal: controller.signal,
    });

    if (!res.ok) {
      // Log only the status code — not the body — to avoid leaking provider internals
      throw new Error(`Brevo responded with status ${res.status}`);
    }
  } finally {
    clearTimeout(timer);
  }
}

// ── Routes ────────────────────────────────────────────────────────────────────

router.post("/auth/send-otp", async (req, res) => {
  const parsed = SendOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const email = parsed.data.email.trim().toLowerCase();

  if (!EMAIL_RE.test(email)) {
    res.status(400).json({ error: "Please enter a valid email address." });
    return;
  }

  if (isRateLimited(sendRateByEmail, email, EMAIL_WINDOW_MS, EMAIL_MAX_SENDS)) {
    res.status(429).json({ error: "Too many OTP requests for this email. Please wait 10 minutes." });
    return;
  }

  const ip = (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0].trim()
    ?? req.socket.remoteAddress
    ?? "unknown";

  if (isRateLimited(sendRateByIp, ip, IP_WINDOW_MS, IP_MAX_SENDS)) {
    res.status(429).json({ error: "Too many requests. Please slow down." });
    return;
  }

  const otp = generateOtp();
  await db
    .insert(otpCodesTable)
    .values({ email, otp, expiresAt: new Date(Date.now() + OTP_TTL_MS), attempts: 0 })
    .onConflictDoUpdate({
      target: otpCodesTable.email,
      set: { otp, expiresAt: new Date(Date.now() + OTP_TTL_MS), attempts: 0 },
    });

  // Opportunistic cleanup of expired rows; never blocks the response.
  cleanupExpired().catch(() => {});

  if (isBrevoConfigured()) {
    try {
      await sendOtpEmail(email, otp);
      req.log.info({ email }, "OTP email sent via Brevo");
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      req.log.error({ email, brevoError: message }, "Failed to send OTP email");
      // Refund both rate-limit slots so a provider outage doesn't lock out the user
      const emailBucket = sendRateByEmail.get(email);
      if (emailBucket && emailBucket.count > 0) emailBucket.count -= 1;
      const ipBucket = sendRateByIp.get(ip);
      if (ipBucket && ipBucket.count > 0) ipBucket.count -= 1;
      // Remove the stored OTP — it was never delivered
      await db.delete(otpCodesTable).where(eq(otpCodesTable.email, email));
      res.status(502).json({ error: "Failed to send verification email. Please try again." });
      return;
    }
    res.json({ success: true, message: `Verification code sent to ${email}`, devOtp: null });
  } else if (process.env.NODE_ENV !== "production") {
    // Brevo not configured — dev/local fallback only: expose OTP in response
    req.log.warn({ email }, "Brevo not configured; returning devOtp in response (dev only)");
    res.json({ success: true, message: `Verification code sent to ${email}`, devOtp: otp });
  } else {
    // Production with no email provider — fail closed
    await db.delete(otpCodesTable).where(eq(otpCodesTable.email, email));
    req.log.error("Brevo not configured in production; rejecting send-otp request");
    res.status(503).json({ error: "Email delivery is not configured. Please contact support." });
  }
});

router.post("/auth/verify-otp", async (req, res) => {
  const parsed = VerifyOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const email    = parsed.data.email.trim().toLowerCase();
  const { otp }  = parsed.data;

  const [entry] = await db.select().from(otpCodesTable).where(eq(otpCodesTable.email, email));
  if (!entry) {
    res.status(400).json({ error: "No OTP found for this email. Please request a new one." });
    return;
  }

  if (Date.now() > entry.expiresAt.getTime()) {
    await db.delete(otpCodesTable).where(eq(otpCodesTable.email, email));
    res.status(400).json({ error: "OTP has expired. Please request a new one." });
    return;
  }

  const attempts = entry.attempts + 1;
  if (attempts > MAX_VERIFY_ATTEMPTS) {
    await db.delete(otpCodesTable).where(eq(otpCodesTable.email, email));
    res.status(400).json({ error: "Too many incorrect attempts. Please request a new OTP." });
    return;
  }

  if (otp !== entry.otp) {
    await db.update(otpCodesTable).set({ attempts }).where(eq(otpCodesTable.email, email));
    const remaining = MAX_VERIFY_ATTEMPTS - attempts;
    res.status(400).json({
      error: `Incorrect OTP. ${remaining} attempt${remaining === 1 ? "" : "s"} remaining.`,
    });
    return;
  }

  await db.delete(otpCodesTable).where(eq(otpCodesTable.email, email));

  // Issue a server-bound verification token so profile endpoints can derive
  // caller identity without trusting client-supplied email values. Persisted
  // to the database (not an in-memory Map) so it survives a deploy/restart.
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + VERIFIED_TTL_MS);

  // One active verification record per email — replace any prior token.
  await db.delete(verificationTokensTable).where(eq(verificationTokensTable.email, email));
  await db.insert(verificationTokensTable).values({ token, email, expiresAt });

  // Also record in the email-keyed table so /auth/send-welcome still works
  // (kept separate from verificationTokensTable — see verifiedEmailsTable doc).
  await db
    .insert(verifiedEmailsTable)
    .values({ email, expiresAt })
    .onConflictDoUpdate({ target: verifiedEmailsTable.email, set: { expiresAt } });

  req.log.info({ email }, "OTP verified successfully");
  res.json({ success: true, message: "Email verified successfully!", verificationToken: token });
});

// ── Welcome email ─────────────────────────────────────────────────────────────

async function sendWelcomeEmail(to: string, name: string, about: string): Promise<void> {
  const apiKey      = process.env.BREVO_API_KEY!;
  const senderEmail = process.env.BREVO_SENDER_EMAIL!;

  // Escape all user-controlled values before HTML interpolation
  const safeName      = escapeHtml(name.trim());
  const safeEmail     = escapeHtml(to);
  const safeFirstName = escapeHtml(name.trim().split(/\s+/)[0]);

  // about is stored as "whatYouDo\nwhatLookingFor"
  const aboutParts        = about.trim().split('\n');
  const safeWhatYouDo     = escapeHtml(aboutParts[0]?.trim() ?? '');
  const safeWhatLookingFor = escapeHtml(aboutParts.slice(1).join(' ').trim());

  const profileRows = [
    safeWhatYouDo     ? `<p style="margin:0 0 4px;font-size:11px;font-weight:600;color:rgba(45,212,191,0.6);letter-spacing:0.06em;text-transform:uppercase;">What you do</p>
                         <p style="margin:0 0 16px;font-size:14px;color:rgba(255,255,255,0.8);line-height:1.5;">${safeWhatYouDo}</p>` : '',
    safeWhatLookingFor ? `<p style="margin:0 0 4px;font-size:11px;font-weight:600;color:rgba(45,212,191,0.6);letter-spacing:0.06em;text-transform:uppercase;">What you&rsquo;re looking for</p>
                          <p style="margin:0 0 16px;font-size:14px;color:rgba(255,255,255,0.8);line-height:1.5;font-style:italic;">&ldquo;${safeWhatLookingFor}&rdquo;</p>` : '',
  ].filter(Boolean).join('');

  const steps: [string, string, string][] = [
    ["📍", "Discover people nearby", "Kinjo surfaces interesting people in your area — no algorithm, no feed, just real proximity."],
    ["💬", "Start a real conversation", "No follower counts, no likes — just a direct line to someone worth meeting."],
    ["✨", "Show up as yourself", "Your profile is your story. The more genuine it is, the better your matches."],
  ];

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>
<body style="margin:0;padding:0;background:#0e0b08;font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0e0b08;padding:40px 16px;">
    <tr><td align="center">
      <table width="100%" style="max-width:480px;">

        <!-- Logo -->
        <tr><td style="padding-bottom:32px;text-align:center;">
          <span style="font-size:26px;font-weight:900;color:#ffffff;letter-spacing:-1px;">Kinjo</span>
        </td></tr>

        <!-- Card -->
        <tr><td style="background:#141210;border:1px solid rgba(255,255,255,0.1);border-radius:14px;padding:40px 36px;">

          <p style="margin:0 0 6px;font-size:24px;font-weight:900;color:#ffffff;letter-spacing:-0.5px;">
            Welcome to Kinjo, ${safeFirstName} &#x1F44B;
          </p>
          <p style="margin:0 0 28px;font-size:14px;color:rgba(255,255,255,0.5);line-height:1.55;">
            You&rsquo;re all set. People nearby can now discover you on Kinjo.
          </p>

          <!-- Profile card — white pill like site CTA -->
          <table width="100%" cellpadding="0" cellspacing="0"
            style="background:#ffffff;border-radius:14px;padding:20px 22px;margin-bottom:28px;">
            <tr><td>
              <p style="margin:0 0 2px;font-size:11px;font-weight:600;color:rgba(0,0,0,0.4);letter-spacing:0.06em;text-transform:uppercase;">Name</p>
              <p style="margin:0 0 ${profileRows ? '14' : '0'}px;font-size:16px;font-weight:700;color:#111111;">${safeName}</p>
              ${profileRows.replace(/color:rgba\(45,212,191,0\.6\)/g, 'color:rgba(0,0,0,0.4)').replace(/color:rgba\(255,255,255,0\.8\)/g, 'color:#333333').replace(/color:rgba\(255,255,255,0\.5\)/g, 'color:rgba(0,0,0,0.45)').replace(/font-style:italic/g, 'font-style:italic;color:#444444')}
              <p style="margin:0 0 2px;font-size:11px;font-weight:600;color:rgba(0,0,0,0.4);letter-spacing:0.06em;text-transform:uppercase;">Email</p>
              <p style="margin:0;font-size:13px;color:rgba(0,0,0,0.45);">${safeEmail}</p>
            </td></tr>
          </table>

          <!-- What's next -->
          <p style="margin:0 0 18px;font-size:15px;font-weight:700;color:#ffffff;">What happens next</p>
          <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:28px;">
            ${steps.map(([icon, title, desc]) => `
            <tr><td style="padding-bottom:18px;">
              <table cellpadding="0" cellspacing="0"><tr>
                <td style="width:38px;vertical-align:top;padding-top:1px;font-size:20px;">${icon}</td>
                <td>
                  <p style="margin:0 0 3px;font-size:14px;font-weight:700;color:#ffffff;">${escapeHtml(title)}</p>
                  <p style="margin:0;font-size:13px;color:rgba(255,255,255,0.45);line-height:1.55;">${escapeHtml(desc)}</p>
                </td>
              </tr></table>
            </td></tr>`).join("")}
          </table>

          <p style="margin:0;font-size:13px;color:rgba(255,255,255,0.25);line-height:1.5;border-top:1px solid rgba(255,255,255,0.08);padding-top:20px;">
            You&rsquo;re receiving this because you signed up for Kinjo.<br>
            If this wasn&rsquo;t you, you can safely ignore this email.
          </p>
        </td></tr>

        <!-- Footer -->
        <tr><td style="padding-top:24px;text-align:center;border-top:1px solid rgba(255,255,255,0.08);margin-top:4px;">
          <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.25);">Kinjo &middot; Discover people around you</p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`.trim();

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), BREVO_TIMEOUT_MS);

  try {
    const res = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: { "Content-Type": "application/json", "api-key": apiKey },
      body: JSON.stringify({
        sender:      { email: senderEmail, name: "Kinjo" },
        to:          [{ email: to, name: safeName }],
        subject:     `Welcome to Kinjo, ${safeFirstName} 🎉`,
        htmlContent: html,
      }),
      signal: controller.signal,
    });

    if (!res.ok) {
      throw new Error(`Brevo responded with status ${res.status}`);
    }
  } finally {
    clearTimeout(timer);
  }
}

router.post("/auth/send-welcome", async (req, res) => {
  const parsed = SendWelcomeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const email = parsed.data.email.trim().toLowerCase();
  const name  = parsed.data.name.trim();
  const about = parsed.data.about?.trim() ?? "";

  if (!name) {
    res.status(400).json({ error: "Name is required." });
    return;
  }

  // Require proof of OTP verification — prevents arbitrary welcome-email spam
  const [verifiedEntry] = await db
    .select()
    .from(verifiedEmailsTable)
    .where(eq(verifiedEmailsTable.email, email));
  if (!verifiedEntry || Date.now() > verifiedEntry.expiresAt.getTime()) {
    res.status(403).json({ error: "Email not verified. Please complete OTP verification first." });
    return;
  }

  // Per-email rate limit: 2 welcome emails per hour
  if (isRateLimited(welcomeRateByEmail, email, WELCOME_EMAIL_WINDOW_MS, WELCOME_EMAIL_MAX)) {
    res.status(429).json({ error: "Too many requests for this email. Please try again later." });
    return;
  }

  // Per-IP rate limit
  const ip = (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0].trim()
    ?? req.socket.remoteAddress
    ?? "unknown";
  if (isRateLimited(welcomeRateByIp, ip, WELCOME_IP_WINDOW_MS, WELCOME_IP_MAX)) {
    res.status(429).json({ error: "Too many requests. Please slow down." });
    return;
  }

  // Consume the verification record — one welcome email per OTP flow
  await db.delete(verifiedEmailsTable).where(eq(verifiedEmailsTable.email, email));

  if (!isBrevoConfigured()) {
    if (process.env.NODE_ENV !== "production") {
      req.log.warn({ email }, "Brevo not configured; skipping welcome email (dev mode)");
      res.json({ success: true, message: "Welcome email skipped (dev mode)." });
    } else {
      req.log.error({ email }, "Brevo not configured in production; welcome email not sent");
      // Non-fatal in production too — user's profile is complete
      res.status(202).json({ success: true, message: "Profile saved. Welcome email could not be sent." });
    }
    return;
  }

  try {
    await sendWelcomeEmail(email, name, about);
    req.log.info({ email }, "Welcome email sent");
    res.json({ success: true, message: "Welcome email sent." });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    req.log.error({ email, brevoError: message }, "Failed to send welcome email");
    // Non-fatal — profile is already saved; don't block the user
    res.status(202).json({ success: true, message: "Profile saved. Welcome email could not be sent." });
  }
});

export default router;
